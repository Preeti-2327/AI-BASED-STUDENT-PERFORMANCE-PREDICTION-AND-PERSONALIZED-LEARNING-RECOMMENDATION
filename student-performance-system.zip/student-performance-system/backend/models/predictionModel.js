// TODO: prediction SQL queries
