// TODO: user SQL queries
