// TODO: marks SQL queries
