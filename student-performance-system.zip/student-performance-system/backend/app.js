const express = require("express");
const cors = require("cors");
const errorHandler = require("./middleware/errorHandler");

const app = express();
app.use(cors());
app.use(express.json());

app.use("/api/auth", require("./routes/authRoutes"));
app.use("/api/admin", require("./routes/adminRoutes"));
app.use("/api/teacher", require("./routes/teacherRoutes"));
app.use("/api/student", require("./routes/studentRoutes"));
app.use("/api/marks", require("./routes/marksRoutes"));
app.use("/api/attendance", require("./routes/attendanceRoutes"));
app.use("/api/predict", require("./routes/predictionRoutes"));
app.use("/api/recommendations", require("./routes/recommendationRoutes"));

app.use(errorHandler);
module.exports = app;
