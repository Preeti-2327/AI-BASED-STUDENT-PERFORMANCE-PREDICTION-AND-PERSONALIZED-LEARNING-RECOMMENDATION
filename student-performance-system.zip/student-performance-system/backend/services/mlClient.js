const ML_URL = process.env.ML_URL || "http://localhost:5001";

async function getPrediction(features) {
  const res = await fetch(`${ML_URL}/predict`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(features),
  });
  if (!res.ok) throw new Error("ML service error");
  return res.json();
}
module.exports = { getPrediction };
