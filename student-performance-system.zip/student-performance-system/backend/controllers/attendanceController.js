// TODO: attendance controller logic
