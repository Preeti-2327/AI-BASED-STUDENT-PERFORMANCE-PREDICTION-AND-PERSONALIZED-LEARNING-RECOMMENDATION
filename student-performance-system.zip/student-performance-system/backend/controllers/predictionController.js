// TODO: prediction controller logic
