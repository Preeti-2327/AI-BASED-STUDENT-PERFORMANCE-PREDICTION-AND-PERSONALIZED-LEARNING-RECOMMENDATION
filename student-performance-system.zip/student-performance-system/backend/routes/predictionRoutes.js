const router = require("express").Router();
// TODO: prediction routes
module.exports = router;
