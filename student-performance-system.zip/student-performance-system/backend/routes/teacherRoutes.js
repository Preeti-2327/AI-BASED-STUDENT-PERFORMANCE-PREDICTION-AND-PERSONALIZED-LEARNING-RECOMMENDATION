const router = require("express").Router();
// TODO: teacher routes
module.exports = router;
