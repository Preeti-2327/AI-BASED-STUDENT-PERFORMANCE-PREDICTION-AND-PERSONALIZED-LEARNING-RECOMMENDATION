const router = require("express").Router();
// TODO: attendance routes
module.exports = router;
