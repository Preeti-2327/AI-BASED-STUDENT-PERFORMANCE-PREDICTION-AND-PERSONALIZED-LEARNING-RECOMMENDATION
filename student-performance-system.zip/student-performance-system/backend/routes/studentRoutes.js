const router = require("express").Router();
// TODO: student routes
module.exports = router;
