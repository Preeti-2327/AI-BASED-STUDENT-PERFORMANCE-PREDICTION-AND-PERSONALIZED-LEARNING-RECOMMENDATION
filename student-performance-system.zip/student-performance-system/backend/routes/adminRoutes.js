const router = require("express").Router();
// TODO: admin routes
module.exports = router;
