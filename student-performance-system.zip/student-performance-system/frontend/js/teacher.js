// teacher page logic
