// student page logic
