from flask import Flask, request, jsonify
import joblib, json, pandas as pd
from recommender import what_if, subject_rules, PLANS

app = Flask(__name__)
clf = joblib.load("models/classifier.pkl")
reg = joblib.load("models/regressor.pkl")
meta = json.load(open("models/meta.json"))
F = meta["features"]

@app.post("/predict")
def predict():
    data = request.get_json()
    X = pd.DataFrame([data])[F]
    level = str(clf.predict(X)[0])
    proba = {str(c): round(float(p), 3)
             for c, p in zip(clf.classes_, clf.predict_proba(X)[0])}
    score, tips = what_if(reg, data, F)
    return jsonify({
        "level": level,
        "probabilities": proba,
        "predicted_score": round(score, 1),
        "model_version": meta["version"],
        "overall_plan": PLANS[level],
        "recommendations": tips,
        "subject_tips": subject_rules(data.get("subjects", [])),
    })

if __name__ == "__main__":
    app.run(port=5001)
