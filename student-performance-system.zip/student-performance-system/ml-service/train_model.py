import json, joblib, numpy as np, pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import (RandomForestClassifier, GradientBoostingClassifier,
                              GradientBoostingRegressor)
from sklearn.metrics import (classification_report, confusion_matrix, accuracy_score,
                             f1_score, mean_absolute_error, mean_squared_error, r2_score)
from sklearn.inspection import permutation_importance

df = pd.read_csv("data/StudentPerformanceFactors.csv").drop_duplicates()
df = df[df["Exam_Score"] <= 100]

NUM = ["Hours_Studied", "Attendance", "Sleep_Hours", "Previous_Scores",
       "Tutoring_Sessions", "Physical_Activity"]
CAT = ["Extracurricular_Activities", "Motivation_Level", "Parental_Involvement",
       "Access_to_Resources", "Internet_Access", "Family_Income", "Teacher_Quality"]
FEATURES = NUM + CAT

q1, q2 = np.percentile(df["Exam_Score"], [33, 66])
df["Level"] = pd.cut(df["Exam_Score"], [-np.inf, q1, q2, np.inf],
                     labels=["Low", "Medium", "High"])

X, y_c, y_r = df[FEATURES], df["Level"], df["Exam_Score"]
Xtr, Xte, yc_tr, yc_te, yr_tr, yr_te = train_test_split(
    X, y_c, y_r, test_size=0.2, random_state=42, stratify=y_c)

def make_pre():
    num = Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())])
    cat = Pipeline([("imp", SimpleImputer(strategy="most_frequent")),
                    ("oh", OneHotEncoder(handle_unknown="ignore"))])
    return ColumnTransformer([("num", num, NUM), ("cat", cat, CAT)])

models = {
    "LogisticRegression": LogisticRegression(max_iter=1000),
    "RandomForest": RandomForestClassifier(n_estimators=300, random_state=42),
    "GradientBoosting": GradientBoostingClassifier(random_state=42),
}
best_name, best_f1 = None, 0
for name, m in models.items():
    pipe = Pipeline([("pre", make_pre()), ("model", m)])
    f1 = cross_val_score(pipe, Xtr, yc_tr, cv=5, scoring="f1_macro").mean()
    print(f"{name}: CV F1 = {f1:.4f}")
    if f1 > best_f1:
        best_name, best_f1 = name, f1

clf = Pipeline([("pre", make_pre()), ("model", models[best_name])]).fit(Xtr, yc_tr)
pred = clf.predict(Xte)
print("Best:", best_name)
print(classification_report(yc_te, pred))
print(confusion_matrix(yc_te, pred, labels=["Low", "Medium", "High"]))

reg = Pipeline([("pre", make_pre()),
                ("model", GradientBoostingRegressor(random_state=42))]).fit(Xtr, yr_tr)
rp = reg.predict(Xte)
mae = mean_absolute_error(yr_te, rp)
rmse = float(np.sqrt(mean_squared_error(yr_te, rp)))
r2 = r2_score(yr_te, rp)
print(f"MAE={mae:.2f} RMSE={rmse:.2f} R2={r2:.3f}")

imp = permutation_importance(clf, Xte, yc_te, n_repeats=5, random_state=42)
pd.Series(imp.importances_mean, index=FEATURES).sort_values().plot.barh()
plt.tight_layout(); plt.savefig("reports/feature_importance.png")

joblib.dump(clf, "models/classifier.pkl")
joblib.dump(reg, "models/regressor.pkl")
json.dump({"version": "1.0", "features": FEATURES, "num": NUM, "cat": CAT,
           "thresholds": [float(q1), float(q2)], "best_model": best_name,
           "accuracy": float(accuracy_score(yc_te, pred)),
           "f1_macro": float(f1_score(yc_te, pred, average="macro")),
           "mae": float(mae), "rmse": rmse, "r2": float(r2)},
          open("models/meta.json", "w"), indent=2)
