import pandas as pd

PLANS = {
    "Low": "Basics se start karo, daily timetable follow karo, teacher se doubt session lo.",
    "Medium": "Weekly revision aur mock tests karo, weak topics par focus rakho.",
    "High": "Advanced problems, competitive exams aur projects try karo.",
}

ACTIONS = [
    {"feature": "Hours_Studied", "mode": "add", "value": 5, "max": 44,
     "tip": "Weekly study hours 5 ghante badhao"},
    {"feature": "Attendance", "mode": "add", "value": 10, "max": 100,
     "tip": "Attendance 10% badhao"},
    {"feature": "Sleep_Hours", "mode": "min", "value": 7,
     "tip": "Roz kam se kam 7 ghante neend lo"},
    {"feature": "Tutoring_Sessions", "mode": "add", "value": 2, "max": 8,
     "tip": "2 extra tutoring/doubt sessions lo"},
    {"feature": "Physical_Activity", "mode": "add", "value": 1, "max": 6,
     "tip": "Physical activity thodi badhao"},
]

def apply(v, a):
    if a["mode"] == "add":
        return min(v + a["value"], a["max"])
    return max(v, a["value"])

def what_if(reg, row, features):
    base = float(reg.predict(pd.DataFrame([row])[features])[0])
    out = []
    for a in ACTIONS:
        new_row = dict(row)
        new_row[a["feature"]] = apply(row[a["feature"]], a)
        new = float(reg.predict(pd.DataFrame([new_row])[features])[0])
        gain = new - base
        if gain >= 0.3:
            out.append({"feature": a["feature"], "tip": a["tip"],
                        "expected_gain": round(gain, 1)})
    out.sort(key=lambda x: -x["expected_gain"])
    return base, out

def subject_rules(subjects):
    tips = []
    for s in subjects:                       # [{"name": "Maths", "marks": 42}, ...]
        if s["marks"] < 50:
            tips.append({"subject": s["name"], "priority": "High",
                         "tip": f"{s['name']} me {s['marks']}% hai. Roz 1 ghanta do."})
        elif s["marks"] < 70:
            tips.append({"subject": s["name"], "priority": "Medium",
                         "tip": f"{s['name']} me weekly test lo aur mistakes note karo."})
    return tips
