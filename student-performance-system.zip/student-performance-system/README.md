# AI Based Student Performance Prediction and Personalized Learning Recommendation

Stack: HTML, CSS, JavaScript | Node.js + Express | MySQL | Python (scikit-learn, Flask)

## Folders
- frontend/    UI pages (admin, teacher, student)
- backend/     Node.js REST API + MySQL
- ml-service/  Kaggle dataset, model training, Flask prediction API
- docs/        Project report PDF

## Run order
1. MySQL: backend/database/schema.sql run karo
2. ML service:
   cd ml-service && pip install -r requirements.txt
   data/ me Kaggle CSV rakho, phir: python train_model.py && python app.py   (port 5001)
3. Backend:
   cd backend && cp .env.example .env && npm install && npm run dev   (port 5000)
4. Frontend: frontend/ ko VS Code Live Server ya koi static server se kholo.
